package com.instainsurance.insuranceappl.services.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.instainsurance.insuranceappl.daos.QuoteDao;
import com.instainsurance.insuranceappl.daos.impl.QuoteDaoImpl;
import com.instainsurance.insuranceappl.models.Quote;
import com.instainsurance.insuranceappl.services.QuoteServices;


@Service
public class QuoteServicesImpl implements QuoteServices {

	@Resource
	private QuoteDao dao;
	
	@Override
	public Boolean insertQuote(Quote quote) {
		return dao.insertQuote(quote);
	}

	@Override
	public Boolean updateQuote(Quote quote) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Boolean deleteQuote(Quote quote) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Quote findByQuoteId(String id) {
		return dao.findByQuoteId(id);
	}

	@Override
	public List<Quote> getQuotes() {
		return dao.getQuotes();
	}

}
