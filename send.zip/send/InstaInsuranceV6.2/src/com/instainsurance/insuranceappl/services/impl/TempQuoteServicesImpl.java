package com.instainsurance.insuranceappl.services.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.instainsurance.insuranceappl.daos.TempQuoteDao;
import com.instainsurance.insuranceappl.daos.VehicleDao;
import com.instainsurance.insuranceappl.daos.impl.TempQuoteImpl;
import com.instainsurance.insuranceappl.exceptions.InsuranceException;
import com.instainsurance.insuranceappl.models.TempQuote;
import  com.instainsurance.insuranceappl.services.TempQuoteServices;


@Service("TempServices")
public class TempQuoteServicesImpl implements TempQuoteServices {

	@Resource
	private TempQuoteDao dao;

	@Override
	public Boolean insertTempQuote(TempQuote tempQuote) throws InsuranceException {
		System.out.println(tempQuote);
		return dao.insertTempQuote(tempQuote);
	}

	@Override
	public Boolean updateTempQuote(TempQuote tempQuote) throws InsuranceException {
		return dao.updateTempQuote(tempQuote);
	}

	@Override
	public Boolean deleteTempQuote(TempQuote tempQuote) throws InsuranceException{
		return dao.deleteTempQuote(tempQuote);
	}

	@Override
	public TempQuote findByTempQuoteId(String id) throws InsuranceException{
		return dao.findByTempQuoteId(id);
	}

	@Override
	public List<TempQuote> getTempQuotes() {
		return dao.getTempQuotes();
		
	}

}
