package com.instainsurance.insuranceappl.controllers;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpRequest;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.instainsurance.insuranceappl.exceptions.InsuranceException;
import com.instainsurance.insuranceappl.models.Claim;
import com.instainsurance.insuranceappl.models.Customer;
import com.instainsurance.insuranceappl.models.Incident;
import com.instainsurance.insuranceappl.models.IncidentReport;
import com.instainsurance.insuranceappl.models.TempQuote;
import com.instainsurance.insuranceappl.models.User;
import com.instainsurance.insuranceappl.models.Vehicle;
import com.instainsurance.insuranceappl.services.ClaimServices;
import com.instainsurance.insuranceappl.services.CustomerServices;
import com.instainsurance.insuranceappl.services.IncidentReportServices;
import com.instainsurance.insuranceappl.services.IncidentServices;
import com.instainsurance.insuranceappl.services.TempQuoteServices;
import com.instainsurance.insuranceappl.services.UserServices;
import com.instainsurance.insuranceappl.services.VehicleServices;

@Controller
public class Control {

	@Autowired
	CustomerServices customerService;

	@Autowired
	VehicleServices vehicleService;

	@Autowired
	TempQuoteServices tempQuoteServices;

	@Autowired
	UserServices userService;

	@Autowired
	ClaimServices claimServices;

	@Autowired
	IncidentServices incidentServices;

	@Autowired
	IncidentReportServices incidentReportServices;
	
	static Logger log = Logger.getLogger(Control.class.getName());

	@RequestMapping(value = "/registerProcess", method = RequestMethod.GET)
	public void addUser(HttpServletRequest request, HttpServletResponse response) {
		

		String firstName = request.getParameter("firstName");
		String lastName = request.getParameter("lastName");
		
		String gender = request.getParameter("gender");
		
		String password = request.getParameter("password");
		
		String dob = request.getParameter("dob");
		
		String email = request.getParameter("email");
		String mobile = request.getParameter("contact");
		Date date1 = null;
		try {
			date1 = new SimpleDateFormat("yyyy-MM-dd").parse(dob);
		} catch (ParseException e) {
			
			e.printStackTrace();
		}
		Customer customer = new Customer();
		int counter = customerService.getCustomer().size();
		String randomId = "CUS" + (++counter);
		customer.setCustomerId(randomId);
		customer.setCustomerDob(date1);
		customer.setCustomerEmail(email);
		customer.setCustomerGender(gender);
		customer.setCustomerPassword(password);
		customer.setCustomerMobNo(mobile);
		customer.setCustomerFirstName(firstName);
		customer.setCustomerLastName(lastName);
		System.out.println(firstName + lastName + gender + password + dob + email + mobile);
		Boolean flag = false;
		try {
			flag = customerService.insertCustomer(customer);
		} catch (InsuranceException e1) {
			log.error("Exception of type InsuranceException.");
			e1.printStackTrace();
		}
		if (flag) {
			try {
				log.info("Customer created with email "+email);
				response.sendRedirect("http://localhost:8089/InstaInsuranceV6.2/index.html");
			} catch (IOException e) {
				log.error("Exception of type IOException.");
				e.printStackTrace();
			}
		} else {
			try {
				log.info("Registration not successful of customer with email "+email);
				response.sendRedirect("http://localhost:8089/InstaInsuranceV6.2/errorPage.html");
			} catch (IOException e) {
				log.error("Exception of type IOException.");
				e.printStackTrace();
			}
		}

	}

	@RequestMapping(value = "/loginProcess", method = RequestMethod.GET)
	public ModelAndView login(HttpServletRequest request, HttpServletResponse response) {

		String userName = request.getParameter("userName");
		String password = request.getParameter("password");
		System.out.println(userName + password);
		Customer customer = null;
		try {
			customer = customerService.findByCustomerId(userName);
		} catch (InsuranceException e1) {
			log.error("Exception of type IOException.");
			e1.printStackTrace();
		}

		if (customer != null && password.equals(customer.getCustomerPassword())) {

			
			log.info("Log In successfull of customer"+customer.getCustomerEmail());

			HttpSession session = request.getSession();

			ModelAndView model = new ModelAndView("dash");
			model.addObject(customer);
			session.setAttribute("name", customer);
			session.setAttribute("customerId", customer.getCustomerId());
			List<Vehicle> vehicles = vehicleService.getVehicles();
			session.setAttribute("vehicles_list", vehicles);
			return model;

		} else {
			try {
				log.info("Log In not successful of user "+userName);
				response.sendRedirect("http://localhost:8089/InstaInsuranceV6.2/index.html");

			} catch (IOException e) {
				log.error("Exception of type IOException");
				e.printStackTrace();
			}
		}

		return null;

	}

	// function mapping for application form

	@RequestMapping(value = "/applicationProcess", method = RequestMethod.GET)
	public ModelAndView application(HttpServletRequest request, HttpServletResponse response) {
		String firstName = request.getParameter("firstName");
		String lastName = request.getParameter("lastName");
		String dob = request.getParameter("dob");
		String gender = request.getParameter("gender");
		String address = request.getParameter("address");
		String contact = request.getParameter("contact");
		String email = request.getParameter("email");
		String passportNo = request.getParameter("passportNo");
		String maritalStatus = request.getParameter("maritalStatus");
		String aadharNo = request.getParameter("aadharNo");

		Customer customer = null;
		try {
			customer = customerService.findByCustomerId(email);
		} catch (InsuranceException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		customer.setCustomerAddress(address);
		customer.setCustomerFirstName(firstName);
		customer.setCustomerLastName(lastName);

		Date date1 = null;
		try {
			date1 = new SimpleDateFormat("yyyy-MM-dd").parse(dob);
		} catch (ParseException e) {
			log.error("Exception of type ParseException.");
			e.printStackTrace();
		}

		customer.setCustomerDob(date1);

		customer.setCustomerGender(gender);
		customer.setCustomerAddress(address);
		customer.setCustomerMobNo(contact);
		customer.setCustomerPassport(passportNo);
		customer.setCustomerMaritalStatus(maritalStatus);
		customer.setCustomerAadhaarNo(aadharNo);

		try {
			customerService.updateCustomer(customer);
		} catch (InsuranceException e) {
			log.error("Exception of type IOException.");
			e.printStackTrace();
		}
		System.out.println(customer.getCustomerId());

		String registrationNo = request.getParameter("registrationNo");
		String age = request.getParameter("age");
		String vehicleValue = request.getParameter("vehicleValue");
		String vehicleType = request.getParameter("vehicleType");
		String vehicleSeats = request.getParameter("vehicleSeats");
		String plateNumber = request.getParameter("plateNumber");
		String engineNumber = request.getParameter("engineNumber");
		String manufacturer = request.getParameter("manufacturer");
		String chasisNumber = request.getParameter("chasisNumber");
		String model = request.getParameter("model");
		String modelNumber = request.getParameter("modelNumber");
		String fuel = request.getParameter("fuel");
		String registrationPlace = request.getParameter("registrationPlace");

		Vehicle vehicle = new Vehicle();

		vehicle.setVehicleOldOrNew(age);
		vehicle.setVehicleValue(vehicleValue);
		vehicle.setVehicleType(vehicleType);
		vehicle.setVehicleNoOfSeat(vehicleSeats);
		vehicle.setVehicleManufacturer(manufacturer);
		vehicle.setVehicleEngineNo(engineNumber);
		vehicle.setVehicleChasisNo(chasisNumber);
		vehicle.setVehicleNumber(plateNumber);
		vehicle.setVehicleModel(model);
		vehicle.setVehicleModelNumber(modelNumber);
		vehicle.setVehicleFuel(fuel);
		vehicle.setVehicleRegistrationPlace(registrationPlace);

		vehicle.setCustomer(customer);

		System.out.println("1" + customer.getCustomerId());

		Vehicle v = vehicleService.findByVehicleCustomer(customer);

		System.out.println("2" + v);

		if (v != null) {
			if (customer.getCustomerId().equals(v.getCustomer().getCustomerId())) {

				v.setVehicleOldOrNew(age);
				v.setVehicleValue(vehicleValue);
				v.setVehicleType(vehicleType);
				v.setVehicleNoOfSeat(vehicleSeats);
				v.setVehicleManufacturer(manufacturer);
				v.setVehicleEngineNo(engineNumber);
				v.setVehicleChasisNo(chasisNumber);
				v.setVehicleNumber(plateNumber);
				v.setVehicleModel(model);
				v.setVehicleModelNumber(modelNumber);
				v.setVehicleFuel(fuel);
				v.setVehicleRegistrationPlace(registrationPlace);
				vehicleService.updateVehicle(v);
				log.info("Application details of the customer "+customer.getCustomerEmail()+" are updated.");

			}

		} else {

			vehicle.setVehicleRegNo(registrationNo);
			vehicleService.insertVehicle(vehicle);
			log.info("New application of customer "+customer.getCustomerEmail()+ "is created.");
		}

		ModelAndView modell = new ModelAndView("homeDashBoard");
		return modell;
	}

	
	
	
	@RequestMapping("/removeSession")
	public void removeSession(HttpSession session, HttpServletResponse response) {
		session.invalidate();
		try {
			log.info("User logged out.");
			response.sendRedirect("http://localhost:8089/InstaInsuranceV6.2/index.html");
		} catch (IOException e) {
			log.error("Exception of type IOException.");
			e.printStackTrace();
		}

	}

	@RequestMapping("/homeDashBoard")
	public ModelAndView homeDashBoard(HttpSession session, HttpServletResponse response, HttpServletRequest request) {

		session = request.getSession(false);
		ModelAndView modelAndView = null;
		if (session != null) {
			modelAndView = new ModelAndView("homeDashBoard");
			return modelAndView;
		} else {
			modelAndView = new ModelAndView("error");
			return modelAndView;

		}

	}

	@RequestMapping("/incident")
	public ModelAndView incident(HttpSession session, HttpServletResponse response, HttpServletRequest request) {

		session = request.getSession(false);
		ModelAndView modelAndView = null;
		if (session != null) {
			modelAndView = new ModelAndView("incident");
			return modelAndView;
		} else {
			modelAndView = new ModelAndView("error");
			return modelAndView;
		}
	}

	@RequestMapping("/application")
	public ModelAndView application(HttpSession session, HttpServletResponse response, HttpServletRequest request) {

		session = request.getSession(false);
		ModelAndView modelAndView = null;
		if (session != null) {
			modelAndView = new ModelAndView("dash");
			return modelAndView;
		}
		else {
			modelAndView = new ModelAndView("error");
			return modelAndView;
		}
	}

	@RequestMapping("/payment")
	public ModelAndView payment(HttpSession session, HttpServletResponse response, HttpServletRequest request) {

		session = request.getSession(false);
		ModelAndView modelAndView = null;
		if (session != null) {
			modelAndView = new ModelAndView("payment");
			return modelAndView;
		} else {
			modelAndView = new ModelAndView("error");
			return modelAndView;
		}
	}

	@RequestMapping("/paymentPortal")
	public ModelAndView paymentPortal(HttpSession session, HttpServletResponse response, HttpServletRequest request) {

		session = request.getSession(false);
		ModelAndView modelAndView = null;
		if (session != null) {
			modelAndView = new ModelAndView("paymentPortal");
			return modelAndView;
		} else {
			modelAndView = new ModelAndView("error");
			return modelAndView;
		}
	}

	@RequestMapping("/contact")
	public ModelAndView contact(HttpSession session, HttpServletResponse response, HttpServletRequest request) {

		session = request.getSession(false);
		ModelAndView modelAndView = null;
		if (session != null) {
			modelAndView = new ModelAndView("contact");
			return modelAndView;
		} else {
			modelAndView = new ModelAndView("error");
			return modelAndView;
		}
	}

	@RequestMapping(value = "/loginProcessStaff", method = RequestMethod.GET)
	public ModelAndView loginStaff(HttpServletRequest request, HttpServletResponse response) {

		String userName = request.getParameter("userName");
		String password = request.getParameter("password");

		User user = userService.findByUserId(userName);
		System.out.println(user);
		if (user != null && password.equals(user.getUserPassword()) && user.getUserRole().equals("staff")) {
			log.info("Staff with username "+userName+" logged In.");
			HttpSession session = request.getSession();
			ModelAndView model = new ModelAndView("staffDashboard");
			session.setAttribute("user", user);
			session.setAttribute("userId", user.getUserId());

			List<Customer> customers = customerService.getCustomer();

			List<Vehicle> vehicles = vehicleService.getVehicles();
			List<Incident> incidents = incidentServices.getIncidents();
			session.setAttribute("customers_list", customers);
			session.setAttribute("incident_list", incidents);
			session.setAttribute("vehicles_list", vehicles);

			return model;

		}

		else if (user != null && password.equals(user.getUserPassword()) && user.getUserRole().equals("admin")) {

			HttpSession session = request.getSession();
			log.info("Admin with username "+userName+" logged In.");
			ModelAndView model = new ModelAndView("adminDashboard");
			List<Customer> customers = customerService.getCustomer();

			List<Vehicle> vehicles = vehicleService.getVehicles();
			List<Incident> incidents = incidentServices.getIncidents();
			session.setAttribute("customers_list", customers);
			session.setAttribute("incident_list", incidents);
			session.setAttribute("vehicles_list", vehicles);
			session.setAttribute("user", user);
			session.setAttribute("userId", user.getUserId());
			return model;

		}

		else if (user != null && password.equals(user.getUserPassword()) && user.getUserRole().equals("verifier")) {

			HttpSession session = request.getSession();
			log.info("Verifier with username "+userName+" logged In.");
			ModelAndView model = new ModelAndView("verifierDashboard");
			List<Vehicle> vehicles = vehicleService.getVehicles();
			session.setAttribute("vehicles_list", vehicles);
			List<Customer> customers = customerService.getCustomer();
			session.setAttribute("customers_list", customers);
			List<Incident> incidents = incidentServices.getIncidents();
			session.setAttribute("incident_list", incidents);

			session.setAttribute("user", user);
			session.setAttribute("userId", user.getUserId());
			return model;

		}

		else {
			try {
				response.sendRedirect("http://localhost:8089/InstaInsuranceV6.2/index.html");
			} catch (IOException e) {
				log.error("Exception of type IOException.");
				e.printStackTrace();
			}
			System.out.println("user doesn't exists");
		}
		return null;
	}

	@RequestMapping("/sendToVerifier")
	public ModelAndView sendToVerifier(HttpSession session, HttpServletResponse response, HttpServletRequest request) {

		String email = request.getParameter("customer_target");
		System.out.println("sending to verifier - " + email);
		Customer customer = null;
		try {
			customer = customerService.findByCustomerId(email);
		} catch (InsuranceException e) {
			e.printStackTrace();
		}
		Vehicle vehicle = vehicleService.findByVehicleCustomer(customer);
		vehicle.setStatus_flag("disapproved");

		vehicleService.updateVehicle(vehicle);
		log.info("Vehicle details of customer "+customer.getCustomerEmail()+" are updated.");

		session = request.getSession(false);
		ModelAndView modelAndView = null;
		if (session != null) {
			modelAndView = new ModelAndView("staffDashboard");
			return modelAndView;
		} else {
			modelAndView = new ModelAndView("error");
			return modelAndView;
		}
	}

	@RequestMapping("/incidentSendToVerifier")
	public ModelAndView incidentSendToVerifier(HttpSession session, HttpServletResponse response,
			HttpServletRequest request) {

		String incidentId = request.getParameter("customer_target");
		Incident incident = null;
		try {
			incident = incidentServices.findByIncidentId(incidentId);
		} catch (InsuranceException e1) {
			log.error("Exception occured of type Insurance Exception.");
			e1.printStackTrace();
		}
		incident.setIncidentStatus("disapproved");
		try {
			incidentServices.updateIncident(incident);
		} catch (InsuranceException e) {
			log.error("Exception occured of type Insurance Exception.");
			e.printStackTrace();
		}

		session = request.getSession(false);
		ModelAndView modelAndView = null;
		if (session != null) {
			modelAndView = new ModelAndView("staffDashboard");
			return modelAndView;
		} else {
			modelAndView = new ModelAndView("error");

			return modelAndView;

		}
	}

	@RequestMapping("/approveStatus")
	public ModelAndView approveStatus(HttpSession session, HttpServletResponse response, HttpServletRequest request) {

		String email = request.getParameter("customer_target");
		Customer customer = null;
		try {
			customer = customerService.findByCustomerId(email);
		} catch (InsuranceException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Vehicle vehicle = vehicleService.findByVehicleCustomer(customer);
		vehicle.setStatus_flag("approved");

		vehicleService.updateVehicle(vehicle);
		log.info("Application of customer "+customer.getCustomerEmail()+ "with vehicle "+vehicle.getVehicleRegNo()+" is updated.");
		

		session = request.getSession(false);
		ModelAndView modelAndView = null;
		if (session != null) {
			modelAndView = new ModelAndView("verifierDashboard");
			return modelAndView;
		} else {
			modelAndView = new ModelAndView("error");
			return modelAndView;
		}
	}

	@RequestMapping("/approveIncident")
	public ModelAndView approveIncident(HttpSession session, HttpServletResponse response, HttpServletRequest request) {

		String incidentId = request.getParameter("customer_target");
		Incident incident = null;
		try {
			incident = incidentServices.findByIncidentId(incidentId);

		} catch (InsuranceException e1) {
			log.error("Exception occured of type Insurance Exception.");
			e1.printStackTrace();
		}
		incident.setIncidentStatus("approved");
		try {
			incidentServices.updateIncident(incident);
		} catch (InsuranceException e) {
			log.error("Exception occured of type Insurance Exception.");
			e.printStackTrace();
		}
		
		ModelAndView modelAndView = null;
		if (session != null) {
			modelAndView = new ModelAndView("verifierDashboard");
			return modelAndView;
		} else {
			modelAndView = new ModelAndView("error");
			return modelAndView;
		}
	}

	@RequestMapping(value = "/insertIncident", method = RequestMethod.GET)
	public ModelAndView insertIncident(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView modelAndView = null;
		modelAndView = new ModelAndView("homeDashBoard");

		Date incidentDate = null;
		String incidentType = request.getParameter("incidentType");
		try {
			incidentDate = new SimpleDateFormat("yyyy-MM-dd").parse(request.getParameter("incidentDate"));
		} catch (ParseException e) {
			e.printStackTrace();
		}
		String incidentDescription = request.getParameter("incidentDescription");
		String incidentImageURL = request.getParameter("incidentImageURL");

		Incident incident = new Incident();
		int incidentId = incidentServices.getIncidents().size() + 1;
		incident.setIncidentId("INC" + incidentId);
		incident.setIncidentType(incidentType);
		incident.setIncidentDate(incidentDate);
		incident.setImage(incidentImageURL);
		incident.setDesc(incidentDescription);
		incident.setIncidentStatus("To be approved");
		try {
			incidentServices.insertIncident(incident);
			log.info("New incident inserted by customer.");
			
		} catch (InsuranceException e) {
			log.error("Exception occured of type Insurance Exception.");
			e.printStackTrace();
		}
		return modelAndView;
	}
	
	
	
	
	
	
	@RequestMapping(value = "/insertUser", method = RequestMethod.GET)
	public ModelAndView insertUser(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView modelAndView = null;
		modelAndView = new ModelAndView("adminDashboard");

		
		String username = request.getParameter("username");
		String password  = request.getParameter("password");
		String role  = request.getParameter("role");
		
		User user = new User();
		
		int userCounter =  userService.getUsers().size();
		
		user.setUserId(++userCounter+"");
		user.setUserName(username);
		user.setUserPassword(password);
		user.setUserRole(role);
		System.out.println("new user with role" + role + "inserted by the admin");
		userService.insertUser(user);
		log.info("New user inserted by admin.");
		return modelAndView;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

	@RequestMapping(value = "/showIncidents", method = RequestMethod.GET)
	public ModelAndView showIncidents() {
		List<Incident> incidents = incidentServices.getIncidents();
		ModelAndView modelAndView = new ModelAndView("IncidentJSP");
		modelAndView.addObject("incidents", incidents);
		return modelAndView;
	}

	@RequestMapping(value = "/showApprovedReports", method = RequestMethod.GET)
	public ModelAndView showApprovedReports() {
		List<IncidentReport> incidentReports = incidentReportServices.getIncidentReports();

		List<IncidentReport> approvedIncidentReports = null;

		for (IncidentReport report : incidentReports) {
			if (report.getApprovalStatus() == "true") {
				approvedIncidentReports.add(report);
			}
		}
		ModelAndView modelAndView = new ModelAndView("IncidentJSP");
		modelAndView.addObject("approvedIncidentReports", approvedIncidentReports);
		return modelAndView;
	}

	@RequestMapping(value = "/showAllReports", method = RequestMethod.GET)
	public ModelAndView showAllReports() {
		List<IncidentReport> incidentReports = incidentReportServices.getIncidentReports();

		ModelAndView modelAndView = new ModelAndView("IncidentJSP");
		modelAndView.addObject("incidentReports", incidentReports);
		return modelAndView;
	}
}
