package com.instainsurance.insuranceappl.daos.impl;

import java.util.List;


import com.instainsurance.insuranceappl.daos.VehicleDao;
import com.instainsurance.insuranceappl.models.Customer;
import com.instainsurance.insuranceappl.models.Vehicle;


import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class VehicleDaoImpl implements VehicleDao {

	@Autowired
	private SessionFactory factory;     
	
	@Override
	public Boolean insertVehicle(Vehicle vehicle) {
		Session session=factory.openSession(); 
		Transaction tn = session.getTransaction();	
		Boolean flag = false;
		try {
			tn.begin();
			session.persist(vehicle);
			tn.commit();
			flag = true;
		} catch(HibernateException e) {
			e.printStackTrace();
			if(tn != null) {
				tn.rollback();		
			}
		} finally {
			session.close();
		}
		return flag;
	}

	@Override
	public Boolean updateVehicle(Vehicle vehicle) {
		Session session=factory.openSession();
		Transaction tn = session.getTransaction();
		Boolean flag = false;
		try {
			tn.begin();
			session.update(vehicle);
			tn.commit();
			flag = true;
		} catch (HibernateException e) {
			if(tn!=null) {
				System.out.println("Error Occurred : "+ e.getMessage());
				tn.rollback();
			}
		} finally {
		session.close();
		}
		return flag;
	}

	@Override
	public Boolean deleteVehicle(Vehicle vehicle) {
		Session session=factory.openSession();
		Transaction tn = session.getTransaction();
		Boolean flag = false;
		System.out.println("Dao delete"+vehicle);
		try {
			tn.begin();
			session.delete(vehicle);
			tn.commit();
			flag = true;
		} catch (HibernateException e) {
			if(tn!=null) {
				System.out.println("Error Occurred : "+ e.getMessage());
				tn.rollback();
			}
		} finally {
		session.close();
		}
		return flag;
	}

	@Override
	public Vehicle findByVehicleId(String id) {
		Session session= factory.openSession();
		Query query=session.createQuery("from Vehicle v where lower(v.customer) like:id")
				.setParameter("id", id.toLowerCase());
		
		if(query.list().size()!=0) {
		Vehicle vh = (Vehicle)(query.list().get(0));
		session.close();
		return vh;
		
		}
		else {
			
			Vehicle vh = null;
			return vh;
		}
	}
	
	
	
	@Override
	public Vehicle findByVehicleCustomer(Customer id) {
		Session session= factory.openSession();
		Query query=session.createQuery("from Vehicle v where v.customer like:id")
				.setParameter("id", id);
		
		if(query.list().size()!=0) {
		Vehicle vh = (Vehicle)(query.list().get(0));
		System.out.println("inside dao " + vh);
		session.close();
		return vh;
		
		}
		else {
			
			Vehicle vh = null;
			return vh;
		}
	}
	
	@Override
	public List<Vehicle> getVehicles() {
		Session session = factory.openSession();
		Query query = session.createQuery("from Vehicle");
		List <Vehicle>list = query.list();
		session.close();
		return list;
	}

}
