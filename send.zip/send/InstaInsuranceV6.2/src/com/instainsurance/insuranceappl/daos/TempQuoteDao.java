package com.instainsurance.insuranceappl.daos;

import java.util.List;

import com.instainsurance.insuranceappl.exceptions.InsuranceException;
import com.instainsurance.insuranceappl.models.TempQuote;

public interface TempQuoteDao {

	Boolean insertTempQuote(TempQuote tempQuote) throws InsuranceException;
	Boolean updateTempQuote(TempQuote tempQuote) throws InsuranceException;
	Boolean deleteTempQuote(TempQuote tempQuote) throws InsuranceException;
	TempQuote findByTempQuoteId(String id) throws InsuranceException;
	List<TempQuote> getTempQuotes();
}
