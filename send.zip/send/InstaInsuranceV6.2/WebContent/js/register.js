function regvalidate()
{

	 var x = document.forms["myform"]["firstName"].value;
	 var y=/^[A-Za-z ]+$/.test(x);
	 if (x == ""&& y==true) {
		document.getElementById('errorname').innerHTML ="First Name must be filled out";
		 return false;
	 }

	 var x = document.forms["myform"]["lastName"].value;
	 if (x == "") {
		document.getElementById('errorname1').innerHTML ="Last Name must be filled out";
		 return false;
	 }

	 var x = document.forms["myform"]["lastName"].value;
	 if (x == "") {
		document.getElementById('errorname1').innerHTML ="Last Name must be filled out";
		 return false;
	 }
	//  var x = document.forms["myform"]["firstName"].value;
	//  if (x == "") {
	// 	document.getElementById('errorname').innerHTML ="Name must be filled out";
	// 	 return false;
	//  }
	//  var x = document.forms["myform"]["firstName"].value;
	//  if (x == "") {
	// 	document.getElementById('errorname').innerHTML ="Name must be filled out";
	// 	 return false;
	//  }
	//  var x = document.forms["myform"]["firstName"].value;
	//  if (x == "") {
	// 	document.getElementById('errorname').innerHTML ="Name must be filled out";
	// 	 return false;
	//  }
 
//  if(document.form.address.value=="")
//  {
// 	document.getElementById('errorname1').innerHTML = "Address should not be empty";
// 	form.address.focus();
// 	return(false);
//  }
 
//  if(document.form.zip.value=="")
//  {
// 	document.getElementById('errorname2').innerHTML = "Please enter zip code";
// 	form.zip.focus();
// 	return(false);
//  }
//  var re=/^\d{6}$/;
//  if(re.test(form.zip.value) == false)
//  {
// 	document.getElementById('errorname2').innerHTML = "Invalid: Zip code should contain 6 digits";
// 	form.zip.focus();
// 	return(false);
//  }
 
//  if(form.email.value=="")
//  {
// 	document.getElementById('errorname3').innerHTML = "Please enter the email";
// 	form.email.focus();
// 	return(false);
//  }
//  var reg=/^(([^<>()\[\]\.,;:\s@\"]+(\.[^<>()\[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/i;
//  if(reg.test(form.email.value) == false)
//  {
// 	document.getElementById('errorname3').innerHTML = "Invalid email";
// 	form.email.focus();
// 	return(false);
//  }
 
 
//  if(document.form.pwd1.value=="")
//  {
// 	document.getElementById('errorname4').innerHTML = "Please type a password";
// 	form.pwd1.focus();
// 	return(false);
//  }
 
//  var r=/^.{6,8}$/;
//  if(r.test(form.pwd1.value) == false)
//  {
// 	document.getElementById('errorname4').innerHTML = "Password should be between 6-8 characters";
// 	form.pwd1.focus();
// 	return(false);
//  }
 
//  if((document.form.pwd1.value) != (document.form.pwd2.value))
//  {
// 	document.getElementById('errorname5').innerHTML = "Password Must be equal";
// 	form.pwd1.value = "";
// 	form.pwd2.value = "";
// 	form.pwd1.focus();
// 	return(false);
//  }
 
else {
	return true;
}
	
}
