package com.lnt.loanApp.tests;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.lnt.loanApp.daos.CustomerDao;
import com.lnt.loanApp.daos.CustomerDaoImpl;
import com.lnt.loanApp.entities.Customer;
import com.lnt.loanApp.entities.CustomerLoan;
import com.lnt.loanApp.entities.Loan;
import com.lnt.loanApp.exceptions.CustomerException;

public class TestServices {

	public static void main(String[] args) {
	ApplicationContext ctx=new ClassPathXmlApplicationContext("springCore.xml");
	CustomerDao c= ctx.getBean(CustomerDao.class);
	try {
		List<Customer> l=c.getCustomerList();
		for(Customer c1 : l)
		{
			System.out.println(c1.getName());
		}
		
	} catch (CustomerException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	try {
		List<Customer> l1=c.getCustomerDetails("anu1@gmail.com");
		for(Customer c1 : l1)
		{
			System.out.println(c1.getName()+ "   "+ c1.getEmail() + "   "+ c1.getCity() + "   "+ c1.getMobile() + "   "+ c1.getPassword());
		}
		
	} catch (CustomerException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	java.util.Date date = new java.util.Date();
	System.out.println(date);
    long t = date.getTime();
    System.out.println(t);
    java.sql.Date sqlDate = new java.sql.Date(t);
    System.out.println(sqlDate);
   //c.addCustomerloanDetails("Apoorva","Female","05-Mar-1996","Indian","General","MUMBAI", 103423,"9106766730","124456754300","AFST124411","AXF17254711","apoorva@gmail.com","individual","Employee","Trainee","LTI","Mumbai");
	
   /* CustomerLoan cl=new CustomerLoan();
    c.addCustomerloanDetails(cl); 
	*/
	
	/*Loan cd=new Loan();
	cd.setLoanType("home");
	cd.setLoanCurrentAmount("400000");
	cd.setLoanPrincipleAmount("300000");
	cd.setLoanDate("12-Jan-2018");
	cd.setAccountNumber("123456789");
	cd.setAadhaar("123456789012");
	cd.setTenure(12);
    
    System.out.println(cd);
	*/
	
		}	
	}


