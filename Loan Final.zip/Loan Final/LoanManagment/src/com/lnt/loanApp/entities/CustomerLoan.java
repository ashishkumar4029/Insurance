package com.lnt.loanApp.entities;

public class CustomerLoan {


private String nameOfBorrower;
private String gender ;
private String dob;
private String nationality;
private String category;
private String address;
private Integer pincode;
private String mobile;
private String aadhaarNo;
private String pan;
private String voterId;
private String email;
private String applyAs;
private String occupation;
private String designation;
private String nameOfOrg;
private String addOfOrg;
private String loanAmount;
private Integer tenure;

public CustomerLoan() {}

public CustomerLoan(String nameOfBorrower, String gender, String dob, String nationality, String category,
		String address, int pincode, String mobile, String aadhaarNo, String pan, String voterId, String email,
		String applyAs, String occupation, String designation, String nameOfOrg, String addOfOrg, String loanAmount, int tenure) {
	super();
	this.nameOfBorrower = nameOfBorrower;
	this.gender = gender;
	this.dob = dob;
	this.nationality = nationality;
	this.category = category;
	this.address = address;
	this.pincode = pincode;
	this.mobile = mobile;
	this.aadhaarNo = aadhaarNo;
	this.pan = pan;
	this.voterId = voterId;
	this.email = email;
	this.applyAs = applyAs;
	this.occupation = occupation;
	this.designation = designation;
	this.nameOfOrg = nameOfOrg;
	this.addOfOrg = addOfOrg;
	this.loanAmount = loanAmount;
	this.tenure = tenure;
}

public String getNameOfBorrower() {
	return nameOfBorrower;
}

public void setNameOfBorrower(String nameOfBorrower) {
	this.nameOfBorrower = nameOfBorrower;
}

public String getGender() {
	return gender;
}

public void setGender(String gender) {
	this.gender = gender;
}

public String getDob() {
	return dob;
}

public void setDob(String dob) {
	this.dob = dob;
}

public String getNationality() {
	return nationality;
}

public void setNationality(String nationality) {
	this.nationality = nationality;
}

public String getCategory() {
	return category;
}

public void setCategory(String category) {
	this.category = category;
}

public String getAddress() {
	return address;
}

public void setAddress(String address) {
	this.address = address;
}

public int getPincode() {
	return pincode;
}

public void setPincode(Integer pincode) {
	this.pincode = pincode;
}

public String getMobile() {
	return mobile;
}

public void setMobile(String mobile) {
	this.mobile = mobile;
}

public String getAadhaarNo() {
	return aadhaarNo;
}

public void setAadhaarNo(String aadhaarNo) {
	this.aadhaarNo = aadhaarNo;
}

public String getPan() {
	return pan;
}

public void setPan(String pan) {
	this.pan = pan;
}

public String getVoterId() {
	return voterId;
}

public void setVoterId(String voterId) {
	this.voterId = voterId;
}

public String getEmail() {
	return email;
}

public void setEmail(String email) {
	this.email = email;
}

public String getApplyAs() {
	return applyAs;
}

public void setApplyAs(String applyAs) {
	this.applyAs = applyAs;
}

public String getOccupation() {
	return occupation;
}

public void setOccupation(String occupation) {
	this.occupation = occupation;
}

public String getDesignation() {
	return designation;
}

public void setDesignation(String designation) {
	this.designation = designation;
}

public String getNameOfOrg() {
	return nameOfOrg;
}

public void setNameOfOrg(String nameOfOrg) {
	this.nameOfOrg = nameOfOrg;
}

public String getAddOfOrg() {
	return addOfOrg;
}

public void setAddOfOrg(String addOfOrg) {
	this.addOfOrg = addOfOrg;
}

public String getLoanAmount() {
	return loanAmount;
}

public void setLoanAmount(String loanAmount) {
	this.loanAmount = loanAmount;
}

public Integer getTenure() {
	return tenure;
}

public void setTenure(Integer tenure) {
	this.tenure = tenure;
}

@Override
public String toString() {
	return "CustomerLoanDetails [nameOfBorrower=" + nameOfBorrower + ", gender=" + gender + ", dob=" + dob
			+ ", nationality=" + nationality + ", category=" + category + ", address=" + address + ", pincode="
			+ pincode + ", mobile=" + mobile + ", aadhaarNo=" + aadhaarNo + ", pan=" + pan + ", voterId=" + voterId
			+ ", email=" + email + ", applyAs=" + applyAs + ", occupation=" + occupation + ", designation="
			+ designation + ", nameOfOrg=" + nameOfOrg + ", addOfOrg=" + addOfOrg + ", loanAmount=" + loanAmount + ", tenure=" + tenure + ", getNameOfBorrower()="
			+ getNameOfBorrower() + ", getGender()=" + getGender() + ", getDob()=" + getDob() + ", getNationality()="
			+ getNationality() + ", getCategory()=" + getCategory() + ", getAddress()=" + getAddress()
			+ ", getPincode()=" + getPincode() + ", getMobile()=" + getMobile() + ", getAadhaarNo()=" + getAadhaarNo()
			+ ", getPan()=" + getPan() + ", getVoterId()=" + getVoterId() + ", getEmail()=" + getEmail()
			+ ", getApplyAs()=" + getApplyAs() + ", getOccupation()=" + getOccupation() + ", getDesignation()="
			+ getDesignation() + ", getNameOfOrg()=" + getNameOfOrg() + ", getAddOfOrg()=" + getAddOfOrg()
			+ ", getLoanAmount()=" + getLoanAmount() +", getTenure()=" + getTenure() +", getClass()=" + getClass() + ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
}



}
