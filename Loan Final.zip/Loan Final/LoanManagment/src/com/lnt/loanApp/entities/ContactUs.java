package com.lnt.loanApp.entities;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity(name="ContactUs")
@Table(name="contact_us")
public class ContactUs {
	@Id
	@Column(name="contact_id")
	private int contactId;
	@Column(name="name")
	private String name;

	@Column(name="email")
	private String email;
	@Column(name="message")
	private String message;
	public ContactUs(int contactId, String name, String email, String message) {
		super();
		this.contactId = contactId;
		this.name = name;
		this.email = email;
		this.message = message;
	}
	public ContactUs() {
		super();
	}
	@Override
	public String toString() {
		return "ContactUs [contactId=" + contactId + ", name=" + name + ", email=" + email + ", message=" + message
				+ "]";
	}
	public int getContactId() {
		return contactId;
	}
	public void setContactId(int contactId) {
		this.contactId = contactId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	
	
	
}
