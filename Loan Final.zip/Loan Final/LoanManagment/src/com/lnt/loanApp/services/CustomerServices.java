package com.lnt.loanApp.services;

import java.util.List;

import com.lnt.loanApp.entities.*;
import com.lnt.loanApp.exceptions.*;

public interface CustomerServices {
	List<Customer> getCustomerList() throws CustomerException;

	void insertCustomer(Customer customerObj)
			throws CustomerException;
	
	void insertCustomerLoan(CustomerLoan customerLoan)
			throws CustomerException;

	void insertLoan(Loan ld) throws CustomerException;
	void insertCustomerAccount(CustomerAccount customerAccount) throws CustomerException;

	List<Loan> getloanIdList() throws CustomerException;
	List<Loan> getMaxloanIdList() throws CustomerException;

	boolean aadhaarVerification(CustomerLoan customerLoan) throws CustomerException;

	List<Customer> getCustomerListbymail(String email) throws CustomerException;


	List<CustomerLoan> getCustomerLoanList(String email) throws CustomerException;

	Customer getCustomerDetails(String email, String password) throws CustomerException;

	List<Loan> getLoanDetails(String aadhaar) throws CustomerException;


	List<CustomerAccount> getAccountDetails(String accountNumber) throws CustomerException;


	void addContactUs(ContactUs contactUs);



	List<ContactUs> getContactUslist() throws CustomerException;


void updateCurrentAmmount(String currentAmount, int loanId) throws CustomerException;

List<CustomerLoan> getCustomerLoanList() throws CustomerException;

}
