function check_eligibility() {
    var a = document.getElementById("income").value;
    var b = document.getElementById("type_of_loan").value;
    if (a <= 300000)
        document.getElementById("demo").innerHTML = "You're not eligible. Sorry!";
    if (a > 300000 && a <= 600000 && b == "home_loan")
        document.getElementById("demo").innerHTML = "You're eligible for a loan of 4 Lacs @ 12%!<br><button class='btn btn-danger' onclick='Redirect_Home();'>Apply for Loan</button>";
    if (a > 600000 && a <= 1000000 && b == "home_loan")
        document.getElementById("demo").innerHTML = "You're eligible for a loan of 6 Lacs @ 12%!<br><button class='btn btn-danger' onclick='Redirect_Home();'>Apply for Loan</button>";
    if (a > 1000000 && a <= 1400000 && b == "home_loan")
        document.getElementById("demo").innerHTML = "You're eligible for a loan of 8 Lacs @ 12%! <br><button class='btn btn-danger' onclick='Redirect_Home();'>Apply for Loan</button>";
    if (a > 1400000 && b == "home_loan")
        document.getElementById("demo").innerHTML = "You're eligible for a loan of 12 Lacs @ 12%!<br><button class='btn btn-danger' onclick='Redirect_Home();'>Apply for Loan</button>";
    if (a <= 300000)
        document.getElementById("demo").innerHTML = "You're not eligible. Sorry!";
    if (a > 300000 && a <= 600000 && b == "vehicle_loan")
        document.getElementById("demo").innerHTML = "You're eligible for a loan of 4 Lacs @ 14%!<br><button class='btn btn-danger' onclick='Redirect_vehicle();'>Apply for Loan</button>";
    if (a > 600000 && a <= 1000000 && b == "vehicle_loan")
        document.getElementById("demo").innerHTML = "You're eligible for a loan of 6 Lacs @ 14%!<br><button class='btn btn-danger' onclick='Redirect_vehicle();'>Apply for Loan</button>";
    if (a > 1000000 && a <= 1400000 && b == "vehicle_loan")
        document.getElementById("demo").innerHTML = "You're eligible for a loan of 8 Lacs @ 14%! <br><button class='btn btn-danger' onclick='Redirect_vehicle();'>Apply for Loan</button>";
    if (a > 1400000 && b == "vehicle_loan")
        document.getElementById("demo").innerHTML = "You're eligible for a loan of 12 Lacs @ 14%!<br><button class='btn btn-danger' onclick='Redirect_vehicle();'>Apply for Loan</button>";
}
function check_eligibility_home() {
    var a = document.getElementById("income_home").value;
    if (a <= 300000)
        document.getElementById("demo_home").innerHTML = "You're not eligible. Sorry!";
    if (a > 300000 && a <= 600000)
        document.getElementById("demo_home").innerHTML = "You're eligible for a loan of 4 Lacs @ 12%!<br><button class='btn btn-danger' onclick='Redirect_Home();'>Apply for Loan</button>";
    if (a > 600000 && a <= 1000000)
        document.getElementById("demo_home").innerHTML = "You're eligible for a loan of 6 Lacs @ 12%!<br><button class='btn btn-danger' onclick='Redirect_Home();'>Apply for Loan</button>";
    if (a > 1000000 && a <= 1400000)
        document.getElementById("demo_home").innerHTML = "You're eligible for a loan of 8 Lacs @ 12%!<br><button class='btn btn-danger' onclick='Redirect_Home();'>Apply for Loan</button>";
    if (a > 1400000)
        document.getElementById("demo_home").innerHTML = "You're eligible for a loan of 12 Lacs @ 12%!<br><button class='btn btn-danger' onclick='Redirect_Home();'>Apply for Loan</button>";
}
function Redirect_Home() {
    window.location = "applyHome.do";
}
function check_eligibility_vehicle() {
    var a = document.getElementById("income_vehicle").value;
    if (a <= 300000)
        document.getElementById("demo_vehicle").innerHTML = "You're not eligible. Sorry!";
    if (a > 300000 && a <= 600000)
        document.getElementById("demo_vehicle").innerHTML = "You're eligible for a loan of 4 Lacs @ 14%!<br><button class='btn btn-danger' onclick='Redirect_vehicle();'>Apply for Loan</button>";
    if (a > 600000 && a <= 1000000)
        document.getElementById("demo_vehicle").innerHTML = "You're eligible for a loan of 6 Lacs @ 14%!<br><button class='btn btn-danger' onclick='Redirect_vehicle();'>Apply for Loan</button>";
    if (a > 1000000 && a <= 1400000)
        document.getElementById("demo_vehicle").innerHTML = "You're eligible for a loan of 8 Lacs @ 14%! <br><button class='btn btn-danger' onclick='Redirect_vehicle();'>Apply for Loan</button>";
    if (a > 1400000)
        document.getElementById("demo_vehicle").innerHTML = "You're eligible for a loan of 12 Lacs @ 14%!<br><button class='btn btn-danger' onclick='Redirect_vehicle();'>Apply for Loan</button>";
}
function Redirect_vehicle() {
    window.location = "applyVehicle.do";
}